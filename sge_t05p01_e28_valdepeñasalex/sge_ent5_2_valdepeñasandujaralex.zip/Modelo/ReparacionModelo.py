
class Reparacion:
    def __init__(self, fecha, coste, descripcion, categoria):
        self._fecha=fecha
        self._coste=coste
        self._descripcion=descripcion
        self._categoria=categoria